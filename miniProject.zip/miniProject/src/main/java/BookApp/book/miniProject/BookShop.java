package BookApp.book.miniProject;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
class BookStore{
	private int bookId;
	private int price;
	private int availableStock;
	private String author;
	private String publisher;
	private LocalDate publishedDate;
	
}
class Customer{
	 int cusId;
	 static String name;
	static long mobile;
	static  String city;
	static int price;
	 static void  addCustomer(Class<?> a2, Connection con) throws SQLException, ClassNotFoundException {
		 Scanner javis=new Scanner(System.in);
			String query2="insert into CustomerTable(name,mobileNumber,Address,membership) values(?,?,?,?)";
		      System.out.println("ENTER YOUR NAME ");
		       	 name=javis.next();
		       	 System.out.println("ENTER YOUR MOBILE NUMBER ");
		         long phone=javis.nextLong();
		          System.out.println("ENTER YOUR ADDRESS ");
		         city=javis.next();
		           
		       PreparedStatement s=con.prepareStatement(query2);
		        Statement s1=con.createStatement();
		        ResultSet set=  s1.executeQuery("select * from CustomerTable");
//			   if(set.next()==false) {
//			      System.out.println("result set size empty");
//			      
//			    }
			   
//			   else
//			   {
//				
//					if(set.getString(1).equals(name) && set.getLong(2)==phone) {
////					
//						PreparedStatement memId=con.prepareStatement("update CustomerTable  set membership=? where name=? and mobileNumber=?");
//						
//						memId.setLong(1,11);
//						memId.setString(2,name);
//						memId.setLong(3, phone);
//						memId.executeUpdate();
//						System.out.println("membership add");
//					}
//					else
//					{
							s.setString(1,name);
							s.setLong(2, phone);
							s.setString(3,city);
							s.setInt(4,0);
							s.executeUpdate();
							System.out.println("new customer");
//					}
//				}
		       
//			   }
		    }
	 
}
class PriviledgedCustomer extends Customer{
	private int membershipId;
	void setmember(int membershipId) {
		this.membershipId=membershipId;
	}
	int getmember() {
		return membershipId;
	}
}
class Options {
	
	Scanner javis=new Scanner(System.in);
	int bookid;
	String bookname;
	String author;
	int price;
	String cusName;


public Options(int bookid,String bookname,String author,int price,String cusName) {
	this.bookid=bookid;
	this.bookname=bookname;
	this.author=author;	
	this.price=price;
	this.cusName=cusName ;
}


public Options() {
	
}


void addBook(Class<?> a2, Connection con) throws SQLException, ClassNotFoundException {
		//ADDING A BOOK INTO TABLE BY USING JDBC
            	 String query1="insert into BookTable2(name,price,availableStock,author,publisher,publishedDate) values(?,?,?,?,?,to_date(?, 'dd-mm-yyyy'))";
            	 System.out.println("ENTER THE BOOK NAME ");
	        	 String a=javis.nextLine();
	        	 System.out.println("ENTER THE PRICE ");
	             int b=javis.nextInt();
	             System.out.println("ENTER AVAILABLE STOCK ");
	             int c=javis.nextInt();
	             System.out.println("ENTER AUTHOR ");
	             String d=javis.next();
	             System.out.println("ENTER PUBLISHER ");
	             String e=javis.next();
	             System.out.println("ENTER THE PUBLISHED DATE : ");
	             String f=javis.next();
	             PreparedStatement s=con.prepareStatement(query1);
	             s.setString(1,a);
	             s.setInt(2, b);
	             s.setInt(3,c);
	             s.setString(4, d);
	             s.setString(5,e);
	             s.setString(6, f);
	             s.executeUpdate();
}

	void addMember(Statement st,Connection con) throws SQLException {
		long mobileNo; boolean member=false;
		Scanner js=new Scanner(System.in);
		System.out.println("enter no");
		mobileNo =js.nextLong();
	
		PreparedStatement memId=con.prepareStatement("update CustomerTable  set membership=? where  MOBILENUMBER=?");

		String query="select * from  CustomerTable";
		ResultSet n=st.executeQuery(query);//	74849494
		while(n.next()) {
		if(n.getLong(2)==mobileNo ) {
			
		memId.setInt(1, 1);
		memId.setLong(2, mobileNo);
		memId.executeUpdate();
		member=true;
			break;					
		}	
		
		}
		if(!member) {
			System.out.println("your data is not available in our database");
		}
		
	}
	void addToCart(ArrayList<Options> list) throws SQLException, ClassNotFoundException {
		System.out.println("ENTER YOUR NAME ");
		String cusName=javis.next();

		System.out.println("ENTER THE BOOK ID TO BE ADDED IN CART ");
		int Bid=javis.nextInt();
		
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","NITHESH35","nithesh");
		Statement st=con.createStatement();
		String query="select * from booktable";
		ResultSet n=st.executeQuery(query);
		while(n.next()) {
	    	   if(Bid==n.getInt(1)) 
	    		   list.add(new Options(Bid,n.getString(2),n.getString(5),n.getInt(3),cusName));
	    	 
	    }
		for(Options o:list) {
			System.out.println("Items added to cart "+o.bookname);
		}
	}
	void removeFromCart(Class<?> a2, Connection con,Statement st,ArrayList<Options> list) throws SQLException {
		 System.out.println("ENTER THE BOOK ID TO BE REMOVED FROM CART ");
		 int s=javis.nextInt();
		 String query="select * from booktable";
		 ResultSet n=st.executeQuery(query);
		 while(n.next()) {
//			for(Options o:list) {
//				if(s==o.bookid) 
//	    		   list.remove(list.get(list.indexOf(o.bookid)));
//	    	 }
			for(int i=0;i<list.size();i++) {
				if(s==list.get(i).bookid) 
	    		   list.remove(list.get(i));
	    	 }
	    }
		for(Options res:list) {
			System.out.println("Items removed from cart  "+res.bookname);
		}
	}
	void checkOut(Statement st,ArrayList<Options> list) throws SQLException {
		int total=0; 
		for(int i=0;i<list.size();i++) {
			total=total+list.get(i).price;
		}
		System.out.println(total);

		
	}
}
public class BookShop{
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		int option;
		Class<?> a= Class.forName("oracle.jdbc.OracleDriver");
	    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","NITHESH35","nithesh");
	    Statement st=con.createStatement();
	      
		System.out.println("SELECT ANY ONE OF THE FOLLOWING OPTIONS");
		System.out.println(" 1.ADD A BOOK\n 2.ADD A CUSTOMER\n 3.ADD A MEMBERSHIP TO A EXISTING CUSTOMER\n 4.ADD A BOOK TO CART\n 5.REMOVE A BOOK FROM CART\n 6.CHECKOUT");
		
		Options obj=new Options();
		ArrayList<Options> list=new ArrayList<Options>();
		Scanner console=new Scanner(System.in); 
		do {
		
			
			System.out.println("enter option u want");
			option=console.nextInt();

		
		switch(option) {
		case 1:
			obj.addBook(a,con);
			break;
		case 2:
			Customer.addCustomer(a,con);
			break;
		case 3:
			obj.addMember( st,con);
			break;
		case 4:
			obj.addToCart(list);
			break;
		case 5:
			obj.removeFromCart(a,con,st,list);
			break;
		case 6:
			obj.checkOut(st,list);
			break;
	}
		if(option==7)
			System.out.println("Thank you for your visit");
	}while(option!=0);		
	
		
		BufferedWriter bw=new BufferedWriter(new FileWriter("C:\\Users\\nithesh\\Desktop\\java tut\\assignment\\miniProject\\src\\main\\java\\report.txt"));
		
		
	
	}
}
		
		
		


//*/
//for(int i=0;i<list.size();i++) {
//	while(n.next()) {
//		if(n.getInt(1)==list.get(i).bookid) 
//		//	System.out.println("book id are "+n.getInt(1));
//		//	int d=n.getInt(3);
//			total=total+n.getInt(3);	
//	}
//	
//
//System.out.println("fin price "+total);
//}
