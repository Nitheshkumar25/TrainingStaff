
public class HeadTailCount {

	public static void main(String[] args) {

	}

}
