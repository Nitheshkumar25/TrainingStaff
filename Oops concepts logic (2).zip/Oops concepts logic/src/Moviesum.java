import java.util.*;
class Movie{
	public String movieTitle,studio;
	public  String		 rating;
	
	Movie(){
		
	}
	Movie(String movieTitle,String studio,String rating ){
		this.movieTitle=movieTitle;
		this.studio=studio;
		
		this.rating=rating;
		
	}
	
	Movie(String movieTitle,String studio){
		this.movieTitle=movieTitle;
		this.studio=studio;
		rating="pg";
	}
	//return a array-list use ArrayList <dataType> -ArrayList<Movie>
	public ArrayList <String>getPg(ArrayList<Movie> m) { // pass customized obj using arraylsit
		ArrayList <String>f1=new ArrayList<>();
		 boolean checkRat=false;
		 ArrayList <String>s=new ArrayList<>();
		for(int i=0;i<m.size();i++)
			if(m.get(i).rating.equalsIgnoreCase("pg")) {
				
				checkRat=true;
				f1.add(m.get(i).movieTitle);
				f1.add(m.get(i).studio);
				f1.add(m.get(i).rating);
				
			}
//		System.out.println(m.get(i).movieTitle +" r.ating"+m.get(i).rating);
		if(checkRat) {
			return f1;
		}
		else
		return s ;
			
	}
}
public class Moviesum {

	public static void main(String[] args) {

		
		ArrayList <Movie>mv=new ArrayList<Movie>();
		mv.add(new Movie("singam","tnCinema","pg-12"));
		mv.add(new Movie("puli ","srisakshi","pg"));
		mv.add(new Movie("bila","tn"));
		mv.add(new Movie("Casino Royale","Eon productions","pg-13"));
		Movie m=new Movie();
		ArrayList <String>s=m.getPg(mv);
	
	for(String s1:s)
		if(s!=null)
		System.out.print(s);
	}

}
