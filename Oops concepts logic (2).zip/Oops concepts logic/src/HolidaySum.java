import java.util.*;
class HoliDay{
	
	private String name,month;
	private int day;boolean compareHolidays=false;
	HoliDay(String name,int day,String month){
		this.name=name;
		
		this.day=day;
		this.month=month;
	}
	
	
	public void isSameMonth(HoliDay obj1,HoliDay obj2) {
		
			if(obj1.month.equals(obj2.month)) {
				compareHolidays=true;
				
			System.out.println(compareHolidays);
			}
	}
}
public class HolidaySum {

	public static void main(String[] args) {
		ArrayList <HoliDay> l=new ArrayList<>();
		
		HoliDay obj1=new HoliDay("deepawali",23,"november");
		HoliDay  obj2=new HoliDay("new year",01,"november");
		obj1.isSameMonth(obj1, obj2);
	}

}
//Holiday[] ha=new Holiday[3];


//Holiday h=new Holiday("Independence Day",15,"August");
//Holiday h1=new Holiday("Republic Day",26,"August");
//Holiday h2=new Holiday("Gndhi Jeyanthi",2,"October");
//
//ha[0]=h;
//ha[1]=h1;
//ha[2]=h2;

//Holiday[] ha=new Holiday[3];
//Holiday h=new Holiday("Independence Day",15,"August");
//Holiday h1=new Holiday("Republic Day",26,"August");
//Holiday h2=new Holiday("Gndhi Jeyanthi",2,"October");
//
//ha[0]=h;
//ha[1]=h1;
//ha[2]=h2;
//

//boolean isSameMonth(Holiday h1) { for single obj
//	return this.month.equals(h1.month);
//}

//public double avgDate(Holiday[] ha) { array of obj
//	int s=0;
//	for(int i=0;i<ha.length;i++) {




