class Counter{
	private int counter=0;
	
	void increment() {
		counter++;
	}
	
	int getValue() {
		return counter;
	}
}
public class CounterOops {

	public static void main(String[] args) {

		
		Counter head,tail;
		head=new Counter();
		tail=new Counter();
		for(int flip=0;flip<100;flip++) {
		if(Math.random()<0.5)
			head.increment();
		else
			tail.increment();
		}
		System.out.println("hed "+head.getValue());
		System.out.println("tail "+tail.getValue());
	}

}
