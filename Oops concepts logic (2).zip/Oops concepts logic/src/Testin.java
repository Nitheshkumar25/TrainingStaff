import java.time.LocalDate;

class Customer {
    private  String name;
    private  boolean member;
    private  String memberType;
    
    public Customer() {
    	this.member=false;
    }
    Customer(String name,boolean member,String memberType){
    	this.name=name;
    	this.member=member;
    	this.memberType=memberType;
    }
    public String getName() {
    	return name;
    }
    public  String isMember() {
    	return memberType;
    }
    public  String getMemberType() {
    	return memberType;
    }
    public  void setMemberType(String memberType) {
        this.memberType=memberType;
    }
   
    public String toString() {
    	return "name= "+name+"\nmember= "+member+"\nmembertype= "+memberType;
    }
}


 class DiscountRate {
	    private static double serviceDiscountPremium=0.2;
	    private static double serviceDiscountGold = 0.15;
	    private static double serviceDiscountSilver = 0.1;
	    private static double productDiscountPremium = 0.1;
	    private static double productDiscountGold = 0.1;
	    private static double productDiscountSilver = 0.1;
	    
	    public static double getServiceDiscountRate(String type) {
	        switch (type) {
	            case "Premium":
	                return serviceDiscountPremium;
	            case "Gold":
	                return serviceDiscountGold;
	            case "Silver":
	                return serviceDiscountSilver;
	            default:
	                throw new IllegalArgumentException("provide correct input");
//	            	?return 
	        }
	    }

	    public static double getProductDiscountRate(String type) {
	        switch (type) {
	            case "Premium":
	                return productDiscountPremium;
	            case "Gold":
	                return productDiscountGold;
	            case "Silver":
	                return productDiscountSilver;
	            default:
	                return  0.0;
	        }
	    }

}
 
 
 class Visit{
	 private String _name;LocalDate date;
	 Visit(String name,LocalDate visitDate2){
		this._name=name ;
		date=visitDate2;
	 }
	 public Visit() {
		// TODO Auto-generated constructor stub
	}
	LocalDate visitDate=LocalDate.now();
	 Customer customer1;
	 DiscountRate dis;
	 double serviceExpense=300.0;
	 double  productExpense=500.0;
	 double newServiceAmt=0;
	 double newProductAmt=0;

	 public void setConstructor(Customer customer) {
		 Visit v=new Visit(customer.getName(),visitDate);
	 }
	 public String getName() {
		 return _name;
	 }
	 	
	 
	 public void getServiceExpense() {
		newServiceAmt= DiscountRate.getServiceDiscountRate( customer1.getMemberType());
	 }
	 public double setServiceExpense() {
		 return (serviceExpense*newServiceAmt)-serviceExpense;
	 }
	public   void getProductExpense() {
		newProductAmt=DiscountRate.getProductDiscountRate(customer1.getMemberType());
	}
	
	public double setProductExpense() {
		return (productExpense*newProductAmt)-productExpense;
	}
	public double getTotalExpens() {
		double s=  setServiceExpense()+setProductExpense();
		return s;
	}
 }
 
 class Saloon2{
 public static void main(String args[] ){
	 
	 Customer c=new Customer("nithesh",true,"Gold");
	 Visit v=new Visit();
	 v.getServiceExpense();
	 v.setServiceExpense();
	 v.getProductExpense();
	 v.setProductExpense();
	 double res=v.getTotalExpens();
	 System.out.println("res "+res);
	
 }
 }