import java.util.*;

class IllegalDiceVal extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IllegalDiceVal(String s) {
	
	super(s);
	}
}
class PairOfDice{
	private int dice1,dice2;
	public int dice1Tot=0,dice2Total=0;

	PairOfDice(){
		dice1=    (int)(6.0 * Math.random());
		dice2=(int)(6.0 * Math.random());

	}
	
	public void roll() {
		setDiceValues();	
	}
	public void setDiceValues() {
		if((dice1>6 && dice2>6) || (dice1<1 && dice2<1)	) {
		try {
			
		throw new IllegalDiceVal("invalid dice val");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		}
		else {
			dice1=(int)(6.0 * Math.random());
			dice2=(int)(6.0 * Math.random());
		}
		
	}
	public int getDiceVal() {
		
		return dice1;
	}
	public int getdice2() {
		return dice2;
	}
	
	  	 public int getTotal() {
	  		return dice1+dice2;
	  	 }
	  	 
	  	 public String  toString() {
	  		 
	  		 return ("dice1 "+dice1 +" dice2 "+dice2);
	  	 }
}
public class Dice {

	public static void main(String[] args) {
		int count=0;
		PairOfDice p=new PairOfDice();
		while(p.getTotal()!=2) {
	p.roll();	
	count++;

		System.out.print(p.toString());
		}
		
System.out.println("total count  until dice val will be 2 "+((count)+1));
	}

}
