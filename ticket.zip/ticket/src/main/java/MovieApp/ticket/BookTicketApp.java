package MovieApp.ticket;
import org.testng.annotations.Test;

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.Scanner;
//
//class Movies{
//	static String name;
//	static String password,movieName,timing;
//	static void bookMovie(Connection con, Scanner sc) throws SQLException{
//		Statement s=con.createStatement();
//		String rs="select * from register";
//		String rs1="select * from movies";
//		ResultSet usrInfo=s.executeQuery(rs);
//		Statement s1=con.createStatement();
//
//		ResultSet movie=s1.executeQuery(rs1);
//		System.out.println("enter a user name");
//		name=sc.next();
//		System.out.println("enter password");
//		password=sc.next();
//		while(usrInfo.next()) {
//			if(usrInfo.getString(1).equals(name) && usrInfo.getString(2).equals(password)) {
//				System.out.println("enter a movie name");
//				movieName =sc.next();
//				while(movie.next()) {
//					if(movieName .equals(movie.getString(1))) {
//						System.out.println("enter a timing with am or pm");
//						timing=sc.next();
//						if(movie.getString(3).equals(timing ))	
//						System.out.println("movie available");
//						else
//							System.out.println("movie unavailable");
//					}
//				}
//			}
//		}
//	}
//	static void addMovie(Connection con, Scanner sc) throws SQLException {
//		//check if the user is admin or  not
//		 System.out.println("enter a user name");
//		 name=sc.next();
//		 System.out.println("enter a password");
//		 password=sc.next();
//		 String query="select * from admin";
//		 Statement stat=con.createStatement();
//		 ResultSet resSet=stat.executeQuery(query);
//		 PreparedStatement pr=con.prepareStatement("insert into movies(name,timing) values(?,?)");
//		 while(resSet .next()) {
//			 if(resSet .getString(1).equals(name)&& resSet.getString(2).equals(password ))
//			 {
//				pr.setString(1, "puli");
//				pr.setString(2, "4.00pm");
//				pr.executeUpdate();
//			 }
//		 }
//		
//	}
//}
//class LoginOrReg{
//	static String name;
//	static String password;
//	void login() {
//		
//	}
//	static void register( Connection con, Scanner sc) throws SQLException {
//		
//		String query="insert into register(name,password ) values (?,?)";
//		//String up="update register set name=?  where f=?";
//		PreparedStatement pr=con.prepareStatement(query);
//		//insert using statment  option
//		Statement stat=con.createStatement();
//		String query1="iinsert into table(name) values('sd')";
//		stat.executeUpdate(query1);
//		name=sc.next();
//		password=sc.next();
//		pr.setString(1, name);
//		pr.setString(2, password );
//		pr.executeUpdate();
//		
//	}
//}
//public class BookTicketApp {
//  public static void main(String[] args) throws SQLException, ClassNotFoundException {
//	  Class<?> a= Class.forName("oracle.jdbc.OracleDriver");
//	    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","NITHESH35","nithesh");
//	    Statement st=con.createStatement();
//	  int option;
//	  System.out.println(" 1.userReg, 2.BookMovie 3.AddMovie 4.DeleteMovie ");
//	  Scanner sc=new Scanner(System.in);
//	 
//	  do {
//		  
//		  option=sc.nextInt();
//		  
//		  switch (option) {
//		case 1:
//			LoginOrReg.register(con,sc);
//			break;
//		case 2:
//			Movies.bookMovie(con, sc);
//			break;
//		case 3:
//			Movies.addMovie(con, sc);
//		case 4:
//			String q="create table nithesh3(name varchar2(20),id number,card number)";
//			st.execute(q);
//		default:
//			break;
//		}
//	  }while(option>0);
//	  
//  }
//}


public class BookTicketApp {
  @Test(priority = 1)
  public void insertCard() {
	  
	 System.out.println("card inserted");
  }
  @Test(priority = 2)
  public void insertPin() {
	  System.out.println("pin inserted");
  }
  
  @Test(priority = 3)
  public void withDraw() {
	  System.out.println("withdraw  choosen");
  }
  @Test(priority = 4) // if we  give same   priority to two method means  it  will execute  those mrthods in alphabet order	
  public void enterAmount() {
	  System.out.println("amount entered");
  }
  @Test(priority = 4)
  public void demoveCard() {
	  System.out.println("card ejected");
  }
}
	
/*insert using statment  option
Statement stat=con.createStatement();
String query1="iinsert into table(name) values('sd')";
stat.executeUpdate(query1); */

//update comment
//		PreparedStatement memId=con.prepareStatement("update CustomerTable  set membership=? where  MOBILENUMBER=?");

//delete a row -"delete from customer  where id=?";
//insert command
//		String query="insert into register(name,password ) values (?,?)";
//create table

//String q="create table nithesh3(name varchar2(20),id number,card number)";
//ddl commands- create ,drop ,alter ,truncate ,RENAME   here we can use -execute()

//dml-insert uodate ,delete- here we can use executeupdate();

//drop ,truncate ref-https://www.w3schools.com/sql/sql_ref_drop_table.asp


//boolean execute() Executes the SQL statement in this PreparedStatement object, which may be any kind of SQL statement.

//ResultSet executeQuery() Executes the SQL query in this PreparedStatement object and returns the ResultSet object generated by the query.

//int executeUpdate() Executes the SQL statement in this PreparedStatement object, which must be an SQL INSERT, UPDATE or DELETE statement; or an SQL statement that returns nothing, such as a DDL statement.
