package Sample1.DatabaseDemo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AppTest {
    int a;
}



Class.forName("oracle.jdbc.OracleDriver");
//System.out.println("driver load succes");
String un="SYSTEM";
String pw="Welcome@123";
String url="jdbc:oracle:thin:@localhost:1521:XE";

System.out.println("************************************************************************************************");
rs = st.executeQuery("select name, max(sub1) as high from surya.student_marks ");
System.out.println("************************************************************************************************");


	rs.close();
st.close();
c.close();
rs = st.executeQuery("select name, sub1+sub2 as total from surya.student_marks");
		//System.out.println("enter a number of peoples");
//		   int n=s.nextInt();
//		   int id;
//		   String name;
//		   int sub1;
//		   int sub2;
//		   String result;
////		   for(int i=1;i<=n;i++) {
//			   System.out.println("Inserting records into the table");   
//			   id=s.nextInt();
//			  name =s.next();
//			   sub1=s.nextInt();
//			   sub2=s.nextInt();
//			   result=s.next();
//			   prepare.setInt(1, id);
//			      prepare.setString(2, name);
//			      prepare.setInt(3, sub1);
//			      prepare.setInt(4, sub2);
//			      prepare.setString(5, result);
//			      prepare.executeUpdate();
//			      System.out.println("Data inserted for people no ----" +i);
//		   }
//		   //insert done--------------------------------
//Select S_Name, (Sub1 + Sub2) as Total from Student_Marks where (Sub1 + Sub2) = (Select Max(Sub1+Sub2) from Student_Marks);
