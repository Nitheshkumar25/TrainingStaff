package Sample1.DatabaseDemo;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
public class App {
  public static void main(String[] args) throws ClassNotFoundException, SQLException {
	  //register the driver class
String url="jdbc:oracle:thin:@localhost:1521:XE";
	Class.forName("oracle.jdbc.driver.OracleDriver") ; 
	System.out.println("driver added sucessfully");
  
	//create a connection
  Connection con=DriverManager.getConnection(url,"NITHESH","Nithesh25");
  System.out.println("connection sucess");
   
  
  //create statement
  Statement st=con.createStatement();
  
  //execute a query
  
  
//  String query1= "CREATE TABLE students " +
//          "(s_id INTEGER not NULL, " +
//          " name1 VARCHAR(255), " + 
//          " email VARCHAR(255), " + 
//          
//       " PRIMARY KEY ( s_id ))"; 
//  
//  st.execute(query1);
  
//  String properst="insert into students(s_id ,name,email) values(?,?,?)";
  Scanner sc=new Scanner(System.in);
//  int row=0;
//  PreparedStatement s=con.prepareStatement(properst);
//  
//  for(int i=0;i<2;i++) {
//	  System.out.println("enter stud id");
//	  int id=sc.nextInt();
//	  System.out.println("enter stud name");
//
//	  String name=sc.next();
//	  System.out.println("enter stud email");
//
//	  String email=sc.next();
//  s.setInt(1,id);
//  s.setString(2, name);
//  s.setString(3, email);
//row=s.executeUpdate();
//
//  }
//  for(int i=0;i<2;i++) {
//	  int ids=sc.nextInt();
//  String query2="delete from students  where id=ids";
//st.executeQuery(query2);
//  }
  
//PreparedStatement s=con.prepareStatement(query2);
//ResultSet n=st.executeQuery(query1);
// while(n.next()) {
// 	System.out.println(n.getInt(1)+" "+n.getString(2));
//}
//  
  
  
  //upadte
//PreparedStatement stmt=con.prepareStatement("update students set s_id=? where name=?");  
//stmt.setInt(1,19); 
//stmt.setString(2,"mani");  
//  
//int ii=stmt.executeUpdate();  

  
  //delete 
  
//  PreparedStatement stat=con.prepareStatement("delete  from students where name=?");
//stat.setString(1,"mani");
//  stat.executeUpdate();
  
  
//  String query="delete vicky.REGISTRATION  where id=?";
//	PreparedStatement stat=con.prepareStatement(query);	
//	 System.out.println("Enter id");
//	  int id=sc.nextInt();
//	
//	stat.setInt(1, id);
//	stat.executeUpdate
//System.out.println(" records updated");

//  if(row>0)
//  	System.out.println("DONE inserted sucess");
//  String insertVal="insert into  reg1 values(4,'mani','a',19,'bio')";
//  st.executeUpdate(insertVal);

//  String alter="alter table reg1 add (dep varchar2(20))";
//  st.executeUpdate(query1);
//  st.executeUpdate(alter);
  //close connection
  
 //select statement
//  String sql = "select * from reg1";
//  ResultSet rs = st.executeQuery(sql);
  // add more rows use create statement;
//  String update = "UPDATE Reg1 " +
//          "SET  dep='cse' WHERE id =1";
//  st.executeUpdate(update);
//  while (rs.next()) {
//      System.out.println("id=" + rs.getInt(1));
//      
//      System.out.println("first=" + rs.getString(2));
//      
//      System.out.println("age "+rs.getInt("age")); //it is a overloaded .we can also give column index -line 41
//    }
  
  //procedures
//  try {
//  String runSp="{call get_employee_id(?,?,?,?)}";
//  CallableStatement callStatement=con.prepareCall(runSp);
//  callStatement.setInt(1, 7839	);
//  callStatement.registerOutParameter(2, java.sql.Types.VARCHAR);
//  callStatement.registerOutParameter(3, java.sql.Types.DATE);
//  
//  callStatement.registerOutParameter(4, java.sql.Types.DECIMAL);
//
//callStatement.executeUpdate();
//
//BigDecimal sal=callStatement.getBigDecimal(4);
//String name=callStatement.getString(3);
//Timestamp createDate=callStatement.getTimestamp(3);
//System.out.println("name is "+name);
//System.out.println("sal is "+sal);
//  }
//  catch(SQLException e) {
////	  System.out.println("sql state ")
//	  e.printStackTrace();
//  }
//  catch(Exception e) {
//	  e.printStackTrace();
//  }
  
  
  
 String query4="create table Librarys(rackid varchar2(10),bookid varchar2(10),book varchar2(20),author_id varchar2(10),author varchar2(20))";	       
	  st.executeUpdate(query4);
String properst="insert into Librarys(rackid ,bookid,book,author_id,author) values('r_03','b_03','emma','a_02','jane')";
 
st.executeUpdate(properst);  
  
         System.out.println("Database created successfully..."); 
         
      String select1= "select * from Librarys";
     ResultSet rs = st.executeQuery(select1);
     while(rs.next()) {
    	 System.out.println("book id "+rs.getString("bookid"));
    	 System.out.println("book name is "+rs.getString("book"));
    	 System.out.println("authour name is "+rs.getString("author"));
     }
     
     //drop column
    String drops= "ALTER TABLE LIBRARYS  DROP COLUMN author_id";  
  System.out.println(  st.executeUpdate(drops)); // if success  it returns 0
  
  //update 
  String bookUpdate="update librarys set book='junit' where bookid='b_03'";
  System.out.println(st.executeUpdate(bookUpdate)); //it sucess column number here it is 3 - book(updated column)
  con.close();

  }	
}	

//execute -used for ddl  commands CREATE , DROP , ALTER , and TRUNCATE

//executeUpdate(): This method is used to execute statements such as 
//insert, update, delete. It returns an integer value representing the number of rows affected.

//executeQuery(): This method is used to execute statements that returns tabular data
//(example select). It returns an object of the class ResultSet.
//prepare statment is used for give  a  value from the user to  insert a values,delete ,in a table

//we can create a prepare statement using connection object at line num 13
//	ex:con.prepareStatement (query);
//PreparedStatement stmt=con.prepareStatement("update students set s_id=? where name=?");  
//stmt.setInt(1,19); 

//stmt.setString(2,"mani");   //here we are setting a value based on thr index pos  ,we can find 
//it by where that question mark position ,pos  index start  from 1
//int ii=stmt.executeUpdate();  
//example:https://www.geeksforgeeks.org/how-to-use-preparedstatement-in-java/

	////Connection to your database
	//Connection con = DriverManager.getConnection();
	//
	//// Query which needs parameters
	//String query = "insert into Students values(?,?)";
	//
	//// Prepare Statement
	//PreparedStatement myStmt
	//    = con.prepareStatement(query);
	//
	//// Set Parameters
	//myStmt.setInt(1, 21);
	//myStmt.setStrin(2, 'Prajjwal');
	//
	//// Execute SQL query
	//int res = myStmt.executeUpdate();
	//
	//// Display the records inserted
	//System.out.println(res + " records inserted");
	//
	//// Close the connection
	//con.close();

//delete 

//PreparedStatement stat=con.prepareStatement("delete  from students where name=?");
//stat.setString(1,"mani"); //here  first argument indicates  the posotion of a parameter
//stat.executeUpdate(); here we can use  prepare statement referece and then run it 
